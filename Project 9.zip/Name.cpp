/********************************************************************
                          Workshop - #9
Full Name  :Arjun Sagar Dhunna
Student ID#:157099219
Email      :adhunna@myseneca.ca
Section    :NHH

Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
************************************************************************/

#define _CRT_SECURE_NO_WARNINGS
#include"Name.h"
#include<string.h>
namespace sdds 
{
    Name::Name()
    {
        this->m_value = nullptr;
    }
    Name::Name(const char* name)
    {
        this->m_value = new char[strlen(name) + 1];
        strcpy(m_value, name);
    }
   
    Name::Name(const Name& name) 
    {
        this->m_value = new char[strlen(name.m_value) + 1];
        strcpy(m_value, name.m_value);
    }
    Name& Name::operator=(const Name& name) 
    {
        if (m_value != nullptr) 
        {
            delete[] m_value;
        }
        this->m_value = new char[strlen(name.m_value) + 1];
        strcpy(m_value, name.m_value);
        return *this;
    }
    Name::~Name() 
    {
        if (m_value != nullptr)
            delete[] m_value;
    }

    Name::operator const char* ()const
    {
        return m_value;
    }
    Name::operator bool()const 
    {
        return m_value != nullptr;
    }
    std::ostream& Name::display(std::ostream& ostr)const
    {
        if (m_value != nullptr)
        {
            ostr << m_value;
        }
        return ostr;
    }
    std::istream& Name::read(std::istream& istr)
    {
        string name;
        istr >> name;
        if (!istr.fail()) 
        {
            istr.ignore(1);
            if (m_value != nullptr) 
            {
                delete[]m_value;
            }
            m_value = new char[strlen(name.c_str()) + 1];
            strcpy(m_value, name.c_str());
        }
        return istr;
    }
    istream& operator>>(istream& in, Name& name)
    {
        return name.read(in);
    }
    ostream& operator<<(ostream& out, Name& name) 
    {
        return name.display(out);
    }
}