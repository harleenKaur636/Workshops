/********************************************************************
                          Workshop - #9
Full Name  :Arjun Sagar Dhunna
Student ID#:157099219
Email      :adhunna@myseneca.ca
Section    :NHH

Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
************************************************************************/

#pragma once
#ifndef SDDS_NAME_H_
#define SDDS_NAME_H_
#include<iostream>
using namespace std;
namespace sdds 
{
    class Name
    {
        char* m_value;
    public:
        Name();
        Name(const char* name);
       
        Name(const Name& old_obj);
        Name& operator=(const Name& other);
        ~Name();

        operator const char* ()const;
        virtual operator bool()const;
        virtual std::ostream& display(std::ostream& ostr = std::cout)const;
        virtual std::istream& read(std::istream& istr = std::cin);
    };
    istream& operator>>(istream& in, Name& name);
    ostream& operator<<(ostream& out, Name& name);
}
#endif