#define _CRT_SECURE_NO_WARNINGS
#include "ConfirmOrder.h"
using namespace std;
namespace sdds {

    ConfirmOrder::ConfirmOrder(const ConfirmOrder& src) {
        *this = src;
    }

    ConfirmOrder& ConfirmOrder::operator=(const ConfirmOrder& src) {
        if (this != &src) {

            delete[] toys;


            toys = new const Toy * [src.co_toyCount];
            for (size_t i = 0; i < src.co_toyCount; i++) {
                toys[i] = src.toys[i];
            }
            co_toyCount = src.co_toyCount;
        }

        return *this;
    }


    ConfirmOrder::ConfirmOrder(ConfirmOrder&& src) noexcept {
        *this = std::move(src);
    }

    ConfirmOrder& ConfirmOrder::operator=(ConfirmOrder&& src) noexcept {
        if (this != &src) {
            delete[] toys;


            toys = src.toys;
            src.toys = nullptr;
            co_toyCount = src.co_toyCount;
            src.co_toyCount = 0;
        }

        return *this;
    }


    ConfirmOrder::~ConfirmOrder() {
        delete[] toys;
    }


    ConfirmOrder& ConfirmOrder::operator+=(const Toy& toy) {

        bool toyExists = false;
        for (size_t i = 0; i < co_toyCount; i++) {
            if (toys[i] == &toy) {
                toyExists = true;
                break;
            }
        }

        if (!toyExists) {

            const Toy** tempToyArr = new const Toy * [co_toyCount + 1];

            for (size_t i = 0; i < co_toyCount; i++) {
                tempToyArr[i] = toys[i];
            }

            tempToyArr[co_toyCount] = &toy;
            co_toyCount++;

            delete[] toys;
            toys = tempToyArr;
        }

        return *this;
    }


    ConfirmOrder& ConfirmOrder::operator-=(const Toy& toy) {

        bool toyExists = false;
        size_t indexFound = -1;
        for (size_t i = 0; i < co_toyCount; i++) {
            if (toys[i] == &toy) {
                toyExists = true;
                indexFound = i;
                break;
            }
        }


        if (toyExists) {
            const Toy** tempToyArr = new const Toy * [co_toyCount - 1];
            size_t origIndex{ 0 };
            for (size_t i = 0; i < co_toyCount; i++) {

                if (i != indexFound) {
                    tempToyArr[origIndex] = toys[i];
                    origIndex++;
                }
            }

            co_toyCount--;
            delete[] toys;
            toys = tempToyArr;
        }

        return *this;
    }


    std::ostream& operator<<(std::ostream& os, const ConfirmOrder& confirmOrder) {
        os << "--------------------------" << std::endl;
        os << "Confirmations to Send" << std::endl;
        os << "--------------------------" << std::endl;

        if (confirmOrder.co_toyCount == 0) {
            os << "There are no confirmations to send!" << std::endl;
        }
        else {
            for (size_t i = 0; i < confirmOrder.co_toyCount; i++) {
                os << *confirmOrder.toys[i];
            }
        }
        os << "--------------------------\n";

        return os;
    }
}