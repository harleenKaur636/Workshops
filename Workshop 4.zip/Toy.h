#ifndef SDDS_TOY_H
#define SDDS_TOY_H
#include <string>
#include <iostream>
namespace sdds {
    class Toy {
    private:
        int t_orderID{ 0 };
        std::string t_name{};
        size_t t_numberOfItems{ 0 };
        double t_price{ 0 };
        double t_hstPercentage{ 13 };
    public:
        // Default Constructor
        Toy() = default;

        // Responsible for extracting information about the toy and storing the tokens in the instance's attributes
        Toy(const std::string& toy);

        // Updates the number of items attribute with the received value
        void update(size_t numItems);

        // Insert the contents of a toy object into an ostream object
        friend std::ostream& operator<<(std::ostream& os, const Toy& toy);
    };
}



#endif // !SDDS_TOY_H


