#ifndef SDDS_CONFIRMORDER_H
#define SDDS_CONFIRMORDER_H
#include "Toy.h"
namespace sdds {
    class ConfirmOrder {
    private:
        const sdds::Toy** toys{ nullptr };
        size_t co_toyCount{ 0 };
    public:
        // Default Constructor
        ConfirmOrder() = default;
        ConfirmOrder(const ConfirmOrder& src);
        ConfirmOrder& operator=(const ConfirmOrder& src);
        ConfirmOrder(ConfirmOrder&& src) noexcept;
        ConfirmOrder& operator=(ConfirmOrder&& src) noexcept;
        ~ConfirmOrder();
        ConfirmOrder& operator+=(const Toy& toy);
        ConfirmOrder& operator-=(const Toy& toy);
        friend std::ostream& operator<<(std::ostream& os, const ConfirmOrder& confirmOrder);
    };
}

#endif // !SDDS_CONFIRMORDER_H


