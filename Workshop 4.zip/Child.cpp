#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "Child.h"
using namespace std;
namespace sdds {

    Child::Child(std::string name, int age, const Toy* toysArr[], size_t count) : c_name(name), c_age(age), c_toyCount(count) {
        if (count > 0) {

            toys = new const Toy * [c_toyCount];
            for (size_t i = 0; i < c_toyCount; i++) {

                toys[i] = new Toy(*(toysArr[i]));
            }
        }
        else {
            toys = nullptr;
        }
    }

    Child::Child(const Child& src) {
        *this = src;
    }

    Child& Child::operator=(const Child& src) {
        if (this != &src) {

            for (size_t i = 0; i < c_toyCount; i++) {
                delete toys[i];
            }
            delete[] toys;
            toys = nullptr;


            if (src.toys) {
                toys = new const Toy * [src.c_toyCount];
                for (size_t i = 0; i < src.c_toyCount; i++) {
                    toys[i] = new Toy(*(src.toys[i]));
                }
            }
            c_name = src.c_name;
            c_age = src.c_age;
            c_toyCount = src.c_toyCount;
        }

        return *this;
    }


    Child::Child(Child&& src) noexcept {
        *this = std::move(src);
    }

    Child& Child::operator=(Child&& src) noexcept {
        if (this != &src) {

            for (size_t i = 0; i < c_toyCount; i++) {
                delete toys[i];
            }
            delete[] toys;
            toys = nullptr;


            toys = src.toys;
            src.toys = nullptr;
            c_name = src.c_name;
            src.c_name = "";
            c_age = src.c_age;
            src.c_age = 0;
            c_toyCount = src.c_toyCount;
            src.c_toyCount = 0;
        }

        return *this;
    }


    Child::~Child() {
        for (size_t i = 0; i < c_toyCount; i++) {
            delete toys[i];
        }
        delete[] toys;
    }


    size_t Child::size() const {
        return c_toyCount;
    }


    std::ostream& operator<<(std::ostream& os, const Child& child) {
        static int call_cnt{ 1 };
        os << "--------------------------" << std::endl;
        os << "Child " << call_cnt << ": " << child.c_name << " " << child.c_age << " years old:" << std::endl;
        os << "--------------------------" << std::endl;
        if (child.size() > 0) {
            for (size_t i = 0; i < child.size(); i++) {
                os << *child.toys[i];
            }
        }
        else {
            os << "This child has no toys!" << std::endl;
        }
        os << "--------------------------" << std::endl;

        call_cnt++;
        return os;
    }
}