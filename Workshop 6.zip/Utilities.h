
#ifndef SDDS_UTILITIES_H
#define SDDS_UTILITIES_H

#include <iostream>
#include <sstream>
#include "Person.h"
#include "Employee.h"
#include "Student.h"
#include "Professor.h"

namespace sdds {

    Person* buildInstance(std::istream& in) {
        //Person* person = nullptr;
        std::string line;
        std::getline(in, line, '\n');
        std::stringstream ss(line);
        std::string type;
        std::getline(ss, type, ',');
        // if (type == "E" || type == "e") {
        //     person = new Employee(ss);
        // }

        if (type == "s" || type == "S") // create a Student object
        {
            try {
                return new Student(ss);
            }
            catch (const std::string& msg) {
                std::cout << msg << std::endl;
                return nullptr;
            }
        }
        else if (type == "p" || type == "P") // create a Professor object
        {
            try {
                return new Professor(ss);
            }
            catch (const std::string& msg) {   //std::cout << "msg" << std::endl;
                std::cout << msg << std::endl;
                return nullptr;
            }
        }
        else if (type == "e" || type == "E") {
            try {
                return new Employee(ss);
            }
            catch (const std::string& msg) {   //std::cout << "msg" << std::endl;
                std::cout << msg << std::endl;
                return nullptr;
            }
        }
        else {
            return nullptr;
        }

        return nullptr;
    }

} // namespace sdds

#endif // SDDS_UTILITIES_H

