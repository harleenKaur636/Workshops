#ifndef SDDS_PROFESSOR_H
#define SDDS_PROFESSOR_H
#include <iostream>
#include <string>
#include "Employee.h" // assuming Employee class is defined in Employee.h



namespace sdds
{
    class Professor : public Employee {
    private:
        std::string m_department;
    public:
        Professor(std::istream& in);

        void display(std::ostream& out) const override {
            Employee::display(out);
            out << m_department << "| Professor";
        }

        std::string status() const override {
            return "Professor";
        }

        std::string department() const;

    };
}

#endif


