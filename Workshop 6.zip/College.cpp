#include <iostream>
#include <iomanip>
#include "College.h"

namespace sdds {
    College& College::operator+=(Person* thePerson) {
        m_persons.push_back(thePerson);
        return *this;
    }

    void College::display(std::ostream& out) const {

        out << "------------------------------------------------------------------------------------------------------------------------" << std::endl;
        out << "|                                        Test #" << 1 << " Persons in the college!                                               |" << std::endl;
        out << "------------------------------------------------------------------------------------------------------------------------" << std::endl;

        for (size_t i = 0; i < m_persons.size(); i++) {
            m_persons[i]->display(out);
            if (i != m_persons.size() - 1) { // check if this is not the last person
                out << std::endl;
            }
        }

        out << std::setw(45) << std::setfill('-') << std::endl;

        out << "------------------------------------------------------------------------------------------------------------------------" << std::endl;
        out << "|                                        Test #" << 2 << " Persons in the college!                                               |" << std::endl;
        out << "------------------------------------------------------------------------------------------------------------------------" << std::endl;

        if (m_persons.empty()) {
            out << "Error: No persons!" << std::endl;
            return;
        }

        for (auto it = m_persons.begin(); it != m_persons.end(); ++it) {

            out << std::setfill(' ') << "| " << std::left << std::setw(10) << (*it)->status() << "| "
                << std::setw(10) << (*it)->id() << "| "
                << std::setw(21) << (*it)->name() << "| "
                << std::left << std::setw(3) << (*it)->age() << " |" << std::endl;
        }
        out << "------------------------------------------------------------------------------------------------------------------------" << std::endl;
    }

    College::~College() {
        for (auto& person : m_persons) {
            delete person;
        }
        m_persons.clear();
    }


}
