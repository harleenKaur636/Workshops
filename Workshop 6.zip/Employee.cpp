#include <iostream>
#include <iomanip>
#include "Employee.h"

namespace sdds {



    // Custom constructor that reads from a stream
    Employee::Employee(std::istream& is) : Person() {
        // Read tag
        // char tag = '\0',coma;
        // is >> tag;
        // is >> coma;  std::cout<<"--"<<tag<<"--"<<coma<<"==";
        // if (tag != 'e' && tag != 'E') { 
        //     throw std::invalid_argument("Invalid tag for Employee.");
        // }
        // Read name
        //std::cout<<"here----\n";
        std::getline(is, m_name, ',');
        m_name = m_name.substr(m_name.find_first_not_of(" "));
        m_name = m_name.substr(0, m_name.find_last_not_of(" ") + 1); //std::cout<<"=="<<m_name<<"--";
        if (m_name.empty()) {
            throw std::invalid_argument("Invalid name for Employee.");
        }
        // Read age
        std::string ageStr;
        std::getline(is, ageStr, ',');
        ageStr = ageStr.substr(ageStr.find_first_not_of(" "));
        ageStr = ageStr.substr(0, ageStr.find_last_not_of(" ") + 1); //std::cout<<"=="<<ageStr<<"==";
        try {
            m_age = std::stoi(ageStr);
        }
        catch (const std::invalid_argument&) {
            throw m_name + "+Invalid record!";
        }
        // Read id
        std::getline(is, m_id, ',');
        m_id = m_id.substr(m_id.find_first_not_of(" "));
        m_id = m_id.substr(0, m_id.find_last_not_of(" ") + 1);//std::cout<<"=="<<m_id<<"==\n";
        if (m_id.empty() || m_id[0] != 'E') {
            throw m_name + "++Invalid record!";
        }
    }

    // Public member functions
    std::string Employee::id() const {
        return m_id;
    }

    std::string Employee::name() const {
        return m_name;
    }

    std::string Employee::age() const {
        return std::to_string(m_age);
    }

    std::string Employee::status() const {
        return "Employee";
    }

    void Employee::display(std::ostream& os) const {
        os << "| " << std::left << std::setw(10) << "Employee " << "| "
            << std::setw(10) << id() << "| "
            << std::setw(21) << name() << "| "
            << std::left << std::setw(3) << age() << " |";
    }

}

