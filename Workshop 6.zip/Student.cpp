#include "Student.h"

namespace sdds {

    // Constructor
    Student::Student(std::istream& in) : m_courses(nullptr), m_count(0) {
        //char tag, delimiter;
        std::string name, id, courses_str;

        // Read record from input stream
        // in >> tag >> delimiter >> std::ws;
        // if (tag != 's' && tag != 'S') {
        //     throw std::invalid_argument("Invalid tag for student record");
        // }

        std::getline(in, name, ',');
        name.erase(0, name.find_first_not_of(" \t\n\r\f\v"));
        name.erase(name.find_last_not_of(" \t\n\r\f\v") + 1);
        //std::cout<<"=="<<name<<"\n";
        m_name = name;
        std::string age_str;
        std::getline(in, age_str, ',');
        age_str.erase(0, age_str.find_first_not_of(" \t\n\r\f\v"));
        age_str.erase(age_str.find_last_not_of(" \t\n\r\f\v") + 1);
        try {
            m_age = std::stoi(age_str);
        }
        catch (const std::invalid_argument&) {
            throw name + "++Invalid record!";
        }

        std::getline(in, id, ',');
        id.erase(0, id.find_first_not_of(" \t\n\r\f\v"));
        id.erase(id.find_last_not_of(" \t\n\r\f\v") + 1);
        if (id.size() < 2 || id[0] != 'S') {
            throw name + "++Invalid record!";
        }
        m_id = id;

        std::string count_str;
        std::getline(in, count_str, ',');
        count_str.erase(0, count_str.find_first_not_of(" \t\n\r\f\v"));
        count_str.erase(count_str.find_last_not_of(" \t\n\r\f\v") + 1);
        try {
            m_count = std::stoi(count_str);
        }
        catch (const std::invalid_argument&) {
            throw name + "++Invalid record!";
        }

        std::getline(in, courses_str);
        courses_str.erase(0, courses_str.find_first_not_of(" \t\n\r\f\v"));
        courses_str.erase(courses_str.find_last_not_of(" \t\n\r\f\v") + 1);

        // Split courses string into individual course names
        std::istringstream iss(courses_str);
        m_courses = new std::string[m_count];
        for (int i = 0; i < m_count; i++) {
            std::getline(iss, m_courses[i], ',');
            m_courses[i].erase(0, m_courses[i].find_first_not_of(" \t\n\r\f\v"));
            m_courses[i].erase(m_courses[i].find_last_not_of(" \t\n\r\f\v") + 1);
        }
    }

    // Destructor
    Student::~Student() {
        delete[] m_courses;
    }



    std::string Student::id() const {
        return m_id;
    }

    std::string Student::age() const {
        return std::to_string(m_age);
    }

    void Student::display(std::ostream& out) const {
        // out << "| Student   | ";
        // out << std::setw(10) << std::left << m_id << " | ";
        // out << std::setw(20) << std::left << m_name << " | ";
        // out << std::setw(3) << std::left << m_age << " | ";
        // out << m_courses[0];
        // for (int i = 1; i < m_count; i++) {
        //     out << ", " << m_courses[i];
        // }
        // out << " |" << std::endl;

        out << "| Student   | "
            << std::left
            << std::setw(10) << m_id << "| "
            << std::setw(21) << m_name << "| "
            << std::left << std::setw(3) << m_age << " |"
            ;

        for (int i = 0; i < m_count - 1; i++)
        {
            out << m_courses[i] << ", ";
        }

        out << m_courses[m_count - 1];

    }


}
