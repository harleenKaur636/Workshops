#ifndef SDDS_COLLEGE_H
#define SDDS_COLLEGE_H

#include <vector>
#include <list>
#include "Person.h"

namespace sdds {
    class College {
        std::vector<Person*> m_persons;

        // Copying disabled
        College(const College& other) = delete;
        College& operator=(const College& other) = delete;

    public:
        College() {};

        // Add a person to the college
        College& operator+=(Person* thePerson);

        // Display all persons in the college
        void display(std::ostream& out) const;

        // Destructor
        ~College();

        template <typename T>
        void select(const T& test, std::list<const Person*>& persons) {
            for (auto& person : m_persons) {
                if (test(person)) {
                    persons.push_back(person);
                }
            }
        }
    };
}

#endif


