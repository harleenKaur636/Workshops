#ifndef SDDS_STUDENT_H
#define SDDS_STUDENT_H
#include <iostream>
#include <sstream>
#include <string>
#include <iomanip>

#include "Person.h" // abstract base class

namespace sdds
{
    class Student : public Person {
    private:
        std::string m_id;
        std::string m_name;
        int m_age;
        std::string* m_courses;
        int m_count;

    public:
        // Constructor
        Student(std::istream& in);

        // Destructor
        ~Student();
        // Disable copy operations
        Student(const Student&) = delete;
        Student& operator=(const Student&) = delete;

        // Query functions
        std::string status() const override {
            return "Student";
        }

        std::string name() const override {
            return m_name;
        }
        std::string id() const;

        std::string age() const;

        void display(std::ostream& out) const;



    };


}

#endif
