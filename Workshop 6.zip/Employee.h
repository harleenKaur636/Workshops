
#ifndef SDDS_EMPLOYEE_H
#define SDDS_EMPLOYEE_H

#include <iostream>
#include <iomanip>
#include <string>
#include "Person.h"

namespace sdds {

    class Employee : public Person {
        std::string m_id;
        std::string m_name;
        int m_age;
    public:
        Employee() {}
        Employee(std::istream& is);
        std::string id() const;
        std::string name() const;
        std::string age() const;
        std::string status() const;
        void display(std::ostream& os) const;
    };

}

#endif // SDDS_EMPLOYEE_H

