#include "Professor.h"

namespace sdds {


    Professor::Professor(std::istream& in) : Employee(in) {
        std::getline(in, m_department);
        m_department = m_department.substr(m_department.find_first_not_of(" "));
        m_department = m_department.substr(0, m_department.find_last_not_of(" ") + 1);
    }



    std::string Professor::department() const {
        return m_department;
    }


}
