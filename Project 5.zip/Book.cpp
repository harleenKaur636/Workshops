#define _CRT_SECURE_NO_WARNINGS
#include <cstring>
#include "Book.h"

using namespace std;
namespace sdds {
    void Book::init_book() {
        title[0] = '\0';
        author[0] = '\0';
        max_chap = 0;
        max_pages = 0;
    }

    Book::Book() {
        init_book();
    }

    Book::Book(const char* title_) {
        init_book();
        strcpy(title, title_);
    }

    Book::Book(const char* title_, const char* author_, double price_) {
        init_book();
        strcpy(title, title_);
        strcpy(author, author_);
        max_price = price_;
    }

    // Print a book summary
    void Book::summary() {
        cout.setf(ios::left);
        cout << "| ";
        cout.width(MAX_BOOK_TITEL);
        cout << title << " | ";
        cout.width(MAX_AUTHOR_NAME);
        cout << author << " | ";
        cout.width(3);
        cout << max_chap << "  ";
        cout.width(4);
        cout << max_pages << " | ";
        cout.width(6);
        cout << max_price << " |" << endl;
    }

    int Book::add_chapter(Chapter* chapter) {
        m_chapters[max_chap++] = *chapter;
        max_pages += int(*chapter);
        return int(max_chap);
    }

    int Book::operator++ (int) {
        return max_chap++;
    }

    void Book::operator+= (Chapter chapter) {
        add_chapter(&chapter);
    }

    void Book::operator-= (double price) {
        max_price -= price;
    }

    ostream& Book::display(std::ostream& os)const {
        os << "Title:'" << title << "'\n";
        os << "Author: '" << author << "'\n";
        for (int i = 0; i < max_chap; i++)
            os << m_chapters[i] << std::endl;
        return os;
    }
}