//****************************************************************************
//Workshop 5 Part 2
//Full Name  : Harleen Kaur
//Student ID#: 163071210
//Email      : hkaur636@myseneca.ca
//Authenticity Declaration:
//I have done all the coding by myself and only copied the code that my 
//professor provided to complete my workshops and assignments. 
//*****************************************************************************

#pragma once
#ifndef SDDS_HERO_H
#define SDDS_HERO_H
#include "Power.h"

namespace sdds {
    class Hero {
        char maximum_name[MAX_NAME_LENGTH];
        int num_power;
        Power* maximum_power;
        int p_level;
    public:
        Hero();
        Hero(const char* name, Power* power, int count_powers);
        ~Hero();
        std::ostream& display() const;
        Hero& operator+=(Power&);
        Hero& operator-=(int);
        friend bool operator<(const Hero&, const Hero&);
        friend bool operator>(const Hero&, const Hero&);
        friend bool operator>>(Power&, Hero&);
        friend bool operator<<(Hero&, Power&);
    };
}
#endif
