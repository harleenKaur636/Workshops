//****************************************************************************
//Workshop 5 Part 2
//Full Name  : Harleen Kaur
//Student ID#: 163071210
//Email      : hkaur636@myseneca.ca
//Authenticity Declaration:
//I have done all the coding by myself and only copied the code that my 
//professor provided to complete my workshops and assignments. 
//*****************************************************************************

#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include <cstring>
#include "Hero.h"

using namespace std;

namespace sdds {

    Hero::Hero() {
        maximum_name[0] = '\0';
        num_power = 0;
        maximum_power->setEmpty();
        p_level = 0;
    }

    Hero::Hero(const char* name, Power* power, int count_powers) {
        int totalRarity = 0;
        strcpy(maximum_name, name);
        num_power = count_powers;
        this->maximum_power = power;
        for (int i = 0; i < num_power; i++) {
            totalRarity += power[i].checkRarity();
        }
        p_level = totalRarity * num_power;
    }

    std::ostream& Hero::display() const {
        cout << "Name: " << maximum_name << endl;
        displayDetails(maximum_power, num_power);
        cout << "Power Level: " << p_level;
        return cout;
    }

    Hero& Hero::operator+=(Power& test) {
        int totalRarity = 0;
        num_power++;
        Power* temp = this->maximum_power;
        this->maximum_power = new Power[num_power];
        for (int i = 0; i < num_power; i++) {
            if (i < num_power - 1) {
                this->maximum_power[i] = temp[i];
            }
            else this->maximum_power[i] = test;
        }
        for (int i = 0; i < num_power; i++) {
            totalRarity += maximum_power[i].checkRarity();
        }
        p_level = totalRarity * num_power;
        return *this;
    }

    Hero& Hero::operator-=(int op) {
        p_level -= op;
        return *this;
    }

    bool operator<(const Hero& hero1, const Hero& hero2) {
        if (hero1.p_level < hero2.p_level) {
            return true;
        }
        else return false;
    }

    bool operator>(const Hero& hero1, const Hero& hero2) {
        if (hero1.p_level > hero2.p_level) {
            return true;
        }
        else return false;
    }

    bool operator>>(Power& power, Hero& hero) {
        hero.operator+=(power);
        return true;
    }

    bool operator<<(Hero& hero, Power& power) {
        hero.operator+=(power);
        return true;
    }

    Hero::~Hero() {
        delete[] maximum_power;
        maximum_power = nullptr;
    }
}
