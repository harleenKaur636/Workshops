#pragma once
#ifndef SDDS_BOOK_H_
#define SDDS_BOOK_H_
#include <iostream>
#include "Chapter.h"

namespace sdds {
    const int MAX_NUM_CHAPTERS = 10;
    const int MAX_BOOK_TITEL = 40;
    const int MAX_AUTHOR_NAME = 20;
    class Book
    {
        char h_title[MAX_BOOK_TITEL + 1];
        char h_author[MAX_AUTHOR_NAME + 1];
        int maximum_chapters;
        int maximum_pages;
        double maximum_price;
        Chapter m_chapters[MAX_NUM_CHAPTERS];

        void init_book();
        int add_chapter(Chapter* chapter);
    public:
        Book();
        Book(const char* title_);
        Book(const char* title_, const char* author_, double price_);
        void summary();
        int operator++ (int);
        operator int() {
            return maximum_chapters;
        }
        operator bool() {
            if (h_title[0] != '\0' && h_author[0] != '\0' && maximum_chapters != 0)
                for (int a = 0; a < maximum_chapters; a++)
                    if (int(m_chapters[a]) != 0)
                        return true;
            return false;
        }
        operator double() {
            return maximum_price;
        }
        operator const char* () {
            return h_title;
        }
        void operator+= (Chapter);
        void operator-= (double);
        std::ostream& display(std::ostream&)const;
        friend std::ostream& operator<<(std::ostream& output, const Book& obj)
        {
            return obj.display(output);
        }
    };
}
#endif
