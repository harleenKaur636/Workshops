//****************************************************************************
//Workshop 5 Part 2
//Full Name  : Harleen Kaur
//Student ID#: 163071210
//Email      : hkaur636@myseneca.ca
//Authenticity Declaration:
//I have done all the coding by myself and only copied the code that my 
//professor provided to complete my workshops and assignments. 
//*****************************************************************************

#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include <cstring>
#include "Power.h"

using namespace std;

namespace sdds {

	Power::Power() {
		this->setEmpty();
	}
	Power::Power(const char* name, int rarity) {
		this->createPower(name, rarity);
	}
	void Power::setEmpty() {
		maximum_name[0] = '\0';
		maximum_rarity = 0;
	}
	void Power::createPower(const char* name, int rarity) {
		if (name && name[0] != '\0' && rarity > 0) {
			strncpy(this->maximum_name, name, MAX_NAME_LENGTH);
			this->maximum_rarity = rarity;
		}
		else {
			this->setEmpty();
		}
	}
	const char* Power::checkName() const {
		return maximum_name;
	}
	int Power::checkRarity() const {
		return maximum_rarity;
	}
	bool Power::isEmpty() const {
		return (maximum_name[0] == '\0' || maximum_rarity == 0);
	}
	void displayDetails(Power* powers, int size) {
		cout << "List of available powers: " << endl;
		for (int i = 0; i < size; i++) {
			if (!powers[i].isEmpty()) {
				cout << "  Name: " << powers[i].checkName() << ", "
					<< "Rarity: " << powers[i].checkRarity() << endl;
			}
		}
	}
}