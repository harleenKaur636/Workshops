#pragma once
#ifndef SDDS_CHAPTER_H_
#define SDDS_CHAPTER_H_
#include <iostream>
#define MAX_CHAPTER_TITLE 20
namespace sdds {
    class Chapter
    {
        char title[MAX_CHAPTER_TITLE + 1];
        int max_pages;
        int max_words;
        unsigned int chap_number;
        void init_chapter();
    public:
        Chapter();
        Chapter(const char* title_);
        Chapter(const char* title_, int chapter_num, int n_pages, int n_words);
        std::ostream& display(std::ostream&)const;
        operator int()
        {
            return max_pages;
        }
        operator double()
        {
            return double(double(max_words) / double(max_pages));
        }
        operator const char* ()
        {
            return title;
        }
        void operator = (const Chapter&);
        int operator ++ ();
        int operator -- ();
        friend std::ostream& operator<<(std::ostream& output, const Chapter& obj)
        {
            return obj.display(output);
        }

    };
}
#endif
