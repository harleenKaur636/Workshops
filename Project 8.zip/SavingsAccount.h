#pragma once
#ifndef SDDS_SAVINGSACCOUNT_H_
#define SDDS_SAVINGSACCOUNT_H_
#include<iostream>
#include"Account.h"
using namespace std;
namespace sdds {
	class SavingsAccount :public Account {
	private:
		double interestRate;
	public:
		SavingsAccount(double, double);
		void monthEnd();
		void display(std::ostream&) const;
	};
}
#endif