#pragma once
#ifndef SDDS_ACCOUNT_H_
#define SDDS_ACCOUNT_H_
#include"iAccount.h"
namespace sdds {
	class Account :public iAccount {
	private:
		double c_balance;
	public:
		Account(double bal = 0.0);
		bool credit(double);
		bool debit(double);
	protected:
		double balance() const;
	};
}
#endif // !SDDS_ACCOUNT_H_
