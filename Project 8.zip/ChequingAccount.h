#pragma once
#ifndef SDDS_CHEQUINGACCOUNT_H_
#define SDDS_CHEQUINGACCOUNT_H_
#include<iostream>
#include"Account.h"
using namespace std;
namespace sdds {
	class ChequingAccount :public Account {
	private:
		double transaction_fee;
		double monthly_fee;
	public:
		ChequingAccount(double, double, double);
		bool credit(double);
		bool debit(double);
		void monthEnd();
		void display(std::ostream&) const;
	};
}
#endif