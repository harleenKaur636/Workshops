#include "Account.h"
namespace sdds {
	Account::Account(double bal) {
		if (bal >= 0) {
			c_balance = bal;
		}
		else {
			c_balance = 0.0;
		}
	}
	bool Account::credit(double val)
	{
		if (val > 0) {
			c_balance += val;
			return true;
		}
		return false;
	}
	bool Account::debit(double val)
	{
		if (val > 0) {
			c_balance -= val;
			return true;
		}

		return false;
	}
	double Account::balance() const
	{
		return c_balance;
	}
}
