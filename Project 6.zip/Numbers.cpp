#define _CRT_SECURE_NO_WARNINGS
#include <cstring>
#include <fstream>
#include "Numbers.h"
#include "Numbers.h"  // intentional
using namespace std;
namespace sdds {


    Numbers::Numbers()
    {
        setEmpty();
        max_orig = false;
    }

    Numbers::Numbers(const char* filename) 
    {
        setEmpty();
        max_orig = true;
        setFilename(filename);
        max_count = numberCount();
        if (max_count == 0 || !load()) 
        {
            delete[] max_num;
            delete[] max_file;
            setEmpty();
            max_orig = false;
        }
        else 
        {
            sort();
        }
    }
    Numbers::~Numbers() 
    {
        save();
        delete[] max_num;
        delete[] max_file;
    }

    bool Numbers::isEmpty() const 
    {
        return max_num == nullptr;
    }

    void Numbers::setEmpty() 
    {
        max_num = nullptr;
        max_file = nullptr;
        max_count = 0;
    }
    void Numbers::setFilename(const char* filename) 
    {
        delete[] max_file;
        max_file = new char[strlen(filename) + 1];
        strcpy(max_file, filename);
    }
    void Numbers::sort() 
    {
        int i, j;
        double temp;
        for (i = max_count - 1; i > 0; i--) 
        {
            for (j = 0; j < i; j++) 
            {
                if (max_num[j] > max_num[j + 1]) 
                {
                    temp = max_num[j];
                    max_num[j] = max_num[j + 1];
                    max_num[j + 1] = temp;
                }
            }
        }
    }

    double Numbers::average() const {
        double aver = 0.0;
        if (!isEmpty()) {
            for (int i = 0; i < max_count; i++)
                aver += max_num[i];
            aver = aver / max_count;
        }
        return aver;
    }
    double Numbers::min() const {
        double minVal = 0.0;
        if (!isEmpty()) {
            minVal = max_num[0];
            for (int i = 1; i < max_count; i++)
                if (minVal > max_num[i]) minVal = max_num[i];
        }
        return minVal;
    }
    double Numbers::max() const {
        double maxVal = 0.0;
        if (!isEmpty()) {
            maxVal = max_num[0];
            for (int i = 1; i < max_count; i++)
                if (maxVal < max_num[i]) maxVal = max_num[i];
        }
        return maxVal;
    }
    Numbers::Numbers(const Numbers& number) {
        this->setEmpty();
        this->max_orig = false;
        *this = number;
    }
    Numbers& Numbers::operator=(const Numbers& number) {
        delete[] this->max_num;
        this->max_num = new double[number.max_count];
        this->max_count = number.max_count;
        for (int i = 0; i < max_count; i++) {
            this->max_num[i] = number.max_num[i];
        }
        return *this;
    }
    int Numbers::numberCount()const {
        int i = 0;
        ifstream f(this->max_file);
        char c;
        while (f.get(c)) {
            if (c == '\n') {
                i++;
            }
        }
        f.close();
        return i;
    }
    bool Numbers::load() {
        int loaded = 0;
        if (this->max_count > 0) {
            this->max_num = new double[this->max_count];
            ifstream f(this->max_file);

            while (f >> this->max_num[loaded]) {
                loaded++;
            }
            f.close();
        }
        return loaded == this->max_count;

    }
    void Numbers::save() {
        if (this->max_orig && !this->isEmpty()) {
            ofstream f(this->max_file);
            for (int i = 0; i < this->max_count; i++) {
                f << this->max_num[i] << '\n';
            }
            f.close();
        }
    }
    Numbers& Numbers::operator += (const double value) {
        if (!this->isEmpty()) {
            double* temp = new double[this->max_count + 1];
            for (int i = 0; i < this->max_count; i++) {
                temp[i] = this->max_num[i];
            }
            temp[max_count] = value;
            this->max_count++;
            delete[] this->max_num;
            this->max_num = temp;
            sort();
        }
        else {
            this->max_num = new double[1];
            this->max_num[0] = value;
            this->max_count = 1;
        }
        return *this;
    }
    std::ostream& Numbers::display(std::ostream& ostr) const {
        if (this->isEmpty()) {
            ostr << "Empty list";
        }
        else {
            ostr << "=========================" << endl;
            if (this->max_orig == true) {
                ostr << this->max_file << endl;
            }
            else {
                ostr << "*** COPY ***" << endl;
            }
            for (int i = 0; i < this->max_count; i++) {
                ostr << this->max_num[i];
                if (i != (max_count - 1)) {
                    ostr << ", ";
                }
                else {
                    ostr << endl;
                }
            }
            ostr << "-------------------------" << endl;
            ostr << "Total of " << max_count << " number(s)" << endl;
            ostr << "Largest number:  " << this->max() << endl;
            ostr << "Smallest number: " << this->min() << endl;
            ostr << "Average :        " << this->average() << endl;
            ostr << "=========================";
        }
        return ostr;
    }
    ostream& operator<<(ostream& os, const Numbers& N) {
        return N.display(os);
    }
    istream& operator>>(istream& istr, Numbers& N) {
        double value;
        istr >> value;
        N += value;
        return istr;
    }

}