#include "Movie.h"
#include <iostream>

namespace sdds {


    std::string& Movie::trim(std::string& str) {
        bool trimmed = false;

        while (!trimmed) {
            trimmed = true;
            if (str.find(' ') == 0) {
                trimmed = false;
                str.erase(str.begin());
            }
            if (str.substr(str.size() - 1, 1).find(' ') != std::string::npos) {
                str.erase(str.end() - 1);
                trimmed = false;
            }
        }
        return str;
    }

    // Default constructor
    Movie::Movie() {
        ; // Intentionally empty
    }


    Movie::Movie(const std::string& strMovie) {
        std::string token{};
        size_t left{};
        size_t right = strMovie.find(",");
        m_title = strMovie.substr(left, right);
        m_title = trim(m_title);
        left = right;
        right = strMovie.find(",", left + 1);
        token = strMovie.substr(left + 1, right - left - 1);
        m_year = std::stoi(token);
        left = right;
        right = strMovie.find('\n', left + 1);
        m_description = strMovie.substr(left + 1, right - left - 1);
        m_description = trim(m_description);
    }

    // Returns a constant reference to the title of the movie
    const std::string& Movie::title() const { return m_title; }

    // Insertion operator overload
    std::ostream& operator<<(std::ostream& os, const Movie& movie) {
        os.width(40);
        os << movie.m_title << " | ";
        os.width(4);
        os << movie.m_year << " | " << movie.m_description << std::endl;
        return os;
    }
}
