#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
	// You will need this when converting from grams to pounds (lbs)
	const double GRAMS_IN_LBS = 453.5924;
	char coffee1_type , coffee2_type, coffee3_type , coffee1_cream, coffee1_strength , maker , grind1 , grind2 , grind3 , best1 , best2 , best3;
	int weight1 = 0, weight2 = 0, weight3 = 0, serve = 0;
	float temp1 = 0, temp2 = 0, temp3 = 0;

	printf("Take a Break - Coffee Shop\n");
	printf("==========================\n\n");
	printf("Enter the coffee product information being sold today...\n\n");

	printf("COFFEE-1...\n");
	printf("Type ([L]ight,[B]lend): ");
	scanf("%c%*c", &coffee1_type);
	printf("Grind size ([C]ourse,[F]ine): ");
	scanf("%c%*c", &grind1);
	printf("Bag weight (g): ");
	scanf("%d%*c", &weight1);
	printf("Best served with coffee1_cream ([Y]es,[N]o): ");
	scanf("%c%*c", &best1);
	printf("Ideal serving temperature (Celsius): ");
	scanf("%f%*c", &temp1);

	printf("\nCOFFEE-2...\n");
	printf("Type ([L]ight,[B]lend): ");
	scanf("%c%*c", &coffee2_type);
	printf("Grind size ([C]ourse,[F]ine): ");
	scanf("%c%*c", &grind2);
	printf("Bag weight (g): ");
	scanf("%d%*c", &weight2);
	printf("Best served with coffee1_cream ([Y]es,[N]o): ");
	scanf("%c%*c", &best2);
	printf("Ideal serving temperature (Celsius): ");
	scanf("%f%*c", &temp2);

	printf("\nCOFFEE-3...\n");
	printf("Type ([L]ight,[B]lend): ");
	scanf("%c%*c", &coffee3_type);
	printf("Grind size ([C]ourse,[F]ine): ");
	scanf("%c%*c", &grind3);
	printf("Bag weight (g): ");
	scanf("%d%*c", &weight3);
	printf("Best served with coffee1_cream ([Y]es,[N]o): ");
	scanf("%c%*c", &best3);
	printf("Ideal serving temperature (Celsius): ");
	scanf("%f%*c", &temp3);

	printf("\n---+---------------+---------------+---------------+-------+--------------\n");
	printf("   |    Coffee     |    Coffee     |   Packaged    | Best  |   Serving    \n");
	printf("   |     Type      |  Grind Size   |  Bag Weight   | Served| Temperature  \n");
	printf("   +---------------+---------------+---------------+ With  +--------------\n");
	printf("ID | Light | Blend | Course | Fine |  (G) | Lbs    | coffee1_cream |   (C) |   (F)\n");
	printf("---+---------------+---------------+---------------+-------+--------------\n");

	printf(" 1 |   %d   |   %d   |    %d   |   %d  | %4d | %6.3lf |   %d   | %5.1lf | %5.1lf\n", \
		((coffee1_type == 'l') || (coffee1_type == 'L')), ((coffee1_type == 'b') || (coffee1_type == 'B')), ((grind1 == 'c') || (grind1 == 'C')), \
		((grind1 == 'f') || (grind1 == 'F')), weight1, (weight1 / GRAMS_IN_LBS), ((best1 == 'y') || (best1 == 'Y')), \
		temp1, (temp1 * 1.8) + 32);

	printf(" 2 |   %d   |   %d   |    %d   |   %d  | %4d | %6.3lf |   %d   | %5.1lf | %5.1lf\n", \
		((coffee2_type == 'l') || (coffee2_type == 'L')), ((coffee2_type == 'b') || (coffee2_type == 'B')), ((grind2 == 'c') || (grind2 == 'C')), \
		((grind2 == 'f') || (grind2 == 'F')), weight2, (weight2 / GRAMS_IN_LBS), ((best2 == 'y') || (best2 == 'Y')), \
		temp2, (temp2 * 1.8) + 32);

	printf(" 3 |   %d   |   %d   |    %d   |   %d  | %4d | %6.3lf |   %d   | %5.1lf | %5.1lf\n\n", \
		((coffee3_type == 'l') || (coffee3_type == 'L')), ((coffee3_type == 'b') || (coffee3_type == 'B')), ((grind3 == 'c') || (grind3 == 'C')), \
		((grind3 == 'f') || (grind3 == 'F')), weight3, (weight3 / GRAMS_IN_LBS), ((best3 == 'y') || (best3 == 'Y')), \
		temp3, (temp3 * 1.8) + 32);

	printf("Enter how you like your coffee and the coffee maker equipment you use...\n\n");


	printf("Coffee coffee1_strength ([M]ild,[R]ich): ");
	scanf("%c%*c", &coffee1_strength);
	printf("Do you like your coffee with coffee1_cream ([Y]es,[N]o): ");
	scanf("%c%*c", &coffee1_cream);
	printf("Typical number of daily servings: ");
	scanf("%d%*c", &serve);
	printf("Maker ([R]esidential,[C]ommercial): ");
	scanf("%c%*c\n\n", &maker);

	printf("\nThe below table shows how your preferences align to the available products:\n\n");

	printf("--------------------+--------------------+-------------+-------+--------------\n");
	printf("  |     Coffee      |      Coffee        |  Packaged   | With  |   Serving    \n");
	printf("ID|      Type       |    Grind Size      | Bag Weight  | coffee1_cream | Temperature  \n");
	printf("--+-----------------+--------------------+-------------+-------+--------------\n");
	printf(" 1|       %d         |        %d           |       %d     |   %d   |      %d      \n", \
		coffee1_strength == 'm' || 'M', maker == 'r' || maker == 'R', serve >= 1 && serve <= 4, \
		coffee1_cream == 'y' || coffee1_cream == 'Y', maker == 'r' || maker == 'R');
	printf(" 2|       %d         |        %d           |       %d     |   %d   |      %d      \n", \
		coffee1_strength == 'r' && 'R', maker == 'c' || 'C', serve >= 1 && serve <= 9, \
		coffee1_cream == 'n' || coffee1_cream == 'N', maker == 'c' || maker == 'C');
	printf(" 3|       %d         |        %d           |       %d     |   %d   |      %d      \n\n", \
		coffee1_strength == 'm' || 'M', maker == 'c' || maker == 'C', serve >= 10, coffee1_cream == 'n' || coffee1_cream == 'N', \
		maker == 'c' || maker == 'C');

	printf("Enter how you like your coffee and the coffee maker equipment you use...\n\n");

	printf("Coffee coffee1_strength ([M]ild,[R]ich): ");
	scanf("%c%*c", &coffee1_strength);
	printf("Do you like your coffee with coffee1_cream ([Y]es,[N]o): ");
	scanf("%c%*c", &coffee1_cream);
	printf("Typical number of daily servings: ");
	scanf("%d%*c", &serve);
	printf("Maker ([R]esidential,[C]ommercial): ");
	scanf("%c%*c\n\n", &maker );

	printf("\nThe below table shows how your preferences align to the available products:\n\n");

	printf("--------------------+--------------------+-------------+-------+--------------\n");
	printf("  |     Coffee      |      Coffee        |  Packaged   | With  |   Serving    \n");
	printf("ID|      Type       |    Grind Size      | Bag Weight  | coffee1_cream | Temperature  \n");
	printf("--+-----------------+--------------------+-------------+-------+--------------\n");
	printf(" 1|       %d         |        %d           |       %d     |   %d   |      %d      \n", \
		coffee1_strength == 'm' && 'M', maker == 'r' || maker == 'R', serve >= 1 && serve <= 4, \
		coffee1_cream == 'y' || coffee1_cream == 'Y', maker == 'r' || maker == 'R');
	printf(" 2|       %d         |        %d           |       %d     |   %d   |      %d      \n", \
		coffee1_strength == 'r' || 'R', maker == 'c' || maker == 'C', serve >= 1 && serve <= 9, \
		coffee1_cream == 'n' || coffee1_cream == 'N', maker == 'c' || maker == 'C');
	printf(" 3|       %d         |        %d           |       %d     |   %d   |      %d      \n\n", \
		coffee1_strength == 'm' && 'M', maker == 'c' || maker == 'C', serve >= 10, coffee1_cream == 'n' || coffee1_cream == 'N', \
		maker == 'c' || maker == 'C');
	printf("Hope you found a product that suits your likes!");
	return 0;
}