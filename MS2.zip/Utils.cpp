/***********************************************************************
// OOP244 Utils Module:
// File  utils.cpp
// Version
// Date
// Author
// Description
//
// Revision History
// -----------------------------------------------------------
// Name            Date            Reason
/////////////////////////////////////////////////////////////////
***********************************************************************/
#include <iostream>
using namespace std;
#include "Utils.h"
namespace sdds
{
	unsigned int getIntInRange(int min, int max)
	{
		int i;
		cin >> i;
		if (cin.fail() || i<min || i>max)
		{
			cin.clear();
			char ch;
			while (cin.get(ch) && ch != '\n')
			{
				;
			}
			cout << "Invalid Selection, try again: ";
			return getIntInRange(min, max);
		}
		else {
			return i;
		}
	}


}