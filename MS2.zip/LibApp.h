#pragma once
#ifndef SDDS_LIBAPP_H__
#define SDDS_LIBAPP_H__
#include"Menu.h"
namespace sdds
{
	class LibApp 
	{
	private:
		bool m_changed;
		Menu m_mainMenu;
		Menu m_exitMenu;
		bool confirm(const char* message);
		void load();  
		void save(); 
		void search();  

		void returnPub();  
							   
	public:
		LibApp();
		void newPublication();
		void removePublication();
		void checkOutPub();
		void run();
		~LibApp();
	};
}
#endif // !