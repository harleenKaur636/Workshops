#pragma once
//Name:   Harleen Kaur
//ID:     163071210
//Email:  hkaur636@myseneca.ca
// Date:  05-08-2022
//Section:ZCCL

#ifndef SDDS_TEMPLATEFUNCTIONS_H_
#define SDDS_TEMPLATEFUNCTIONS_H_
#include <iostream>
#include "Collection.h"
namespace sdds
{
	//Find with 3 parameters
	template <typename T, typename T2> bool find(T col[], int index, T2 key) 
	{
		return col[index] == key;
	}

	//Find with 4 parameters
	template <typename T, typename T2, typename T3> int find(T col[], int size, T2 key1, T3 key2)
	{
		for (int i = 0; i < size; i++) 
		{
			if (find(col, i, key1) && find(col, i, key2))
			{
				return i;
			}
		}
		return -1;
	}

	//Insertion operator
	template <typename T> std::ostream& operator << (std::ostream& os, Collection<T>& col)
	{
		for (int i = 0; i < col.size(); i++)
		{
			os << col[i] << std::endl;
		}
		return os;

	}

	//Load Collection
	template <typename T> Collection<T>& loadCollection(Collection<T>& col, T obj) 
	{
		col += obj;
		return col;
	}

}
#endif // !SDDS_SEARCH_H_

