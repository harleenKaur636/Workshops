/*
*****************************************************************************
                          Workshop - #3 (P2)
Full Name  :Harleen Kaur
Student ID#:163071210
Email      :hkaur636@myseneca.ca
Section    :ZGG

Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
*****************************************************************************
*/

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

int main(void)
{
    const double TAX = 0.13;
    const char patSize = 'S', salSize = 'M', tomSize = 'L';
    double small, medium, large, average1, average2;
    int asmall, amedium, alarge, subtotal, taxtotal, TOTAL, Pshirts, Tshirts, Sshirts, sub1, tax1, total1, sub2, tax2, total2, sub3, tax3, total3;

    printf("Set Shirt Prices\n");
    printf("================\n");
    printf("Enter the price for a SMALL shirt: $");
    scanf("%lf", &small);
    printf("Enter the price for a MEDIUM shirt: $");
    scanf("%lf", &medium);
    printf("Enter the price for a LARGE shirt: $");
    scanf("%lf", &large);

    printf("\n");

    asmall = small * 100;
    amedium = medium * 100;
    alarge = large * 100;

    printf("Shirt Store Price List\n");
    printf("======================\n");
    printf("SMALL  : $%.2lf\n", (double)asmall / 100);
    printf("MEDIUM : $%.2lf\n", (double)amedium / 100);
    printf("LARGE  : $%.2lf\n", (double)alarge / 100);

    printf("\nPatty's shirt size is '%c'\n", patSize);
    printf("Number of shirts Patty is buying: ");
    scanf("%d", &Pshirts);

    printf("\nTommy's shirt size is '%c'\n", tomSize);
    printf("Number of shirts Tommy is buying: ");
    scanf("%d", &Tshirts);

    printf("\nSally's shirt size is '%c'\n", salSize);
    printf("Number of shirts Sally is buying: ");
    scanf("%d", &Sshirts);

    sub1 = asmall * Pshirts;
    tax1 = ((sub1 * (TAX * 100)) + 50) / 100;
    total1 = (sub1 + tax1);
    sub2 = amedium * Sshirts;
    tax2 = ((sub2 * (TAX * 100)) + 50) / 100;
    total2 = (sub2 + tax2);
    sub3 = alarge * Tshirts;
    tax3 = ((sub3 * (TAX * 100)) + 50) / 100;
    total3 = (sub3 + tax3);
    subtotal = (sub1 + sub2 + sub3);
    taxtotal = (tax1 + tax2 + tax3);
    TOTAL = (total1 + total2 + total3);

    printf("\nCustomer Size Price Qty Sub-Total       Tax     Total\n");
    printf("-------- ---- ----- --- --------- --------- ---------\n");
    printf("Patty    %-4c %5.2lf %3d %9.4lf %9.4lf %9.4lf\n", patSize, (double)asmall / 100, Pshirts, (double)sub1 / 100, (double)tax1 / 100, (double)total1 / 100);
    printf("Sally    %-4c %5.2lf %3d %9.4lf %9.4lf %9.4lf\n", salSize, (double)amedium / 100, Sshirts, (double)sub2 / 100, (double)tax2 / 100, (double)total2 / 100);
    printf("Tommy    %-4c %5.2lf %3d %9.4lf %9.4lf %9.4lf\n", tomSize, (double)alarge / 100, Tshirts, (double)sub3 / 100, (double)tax3 / 100, (double)total3 / 100);
    printf("-------- ---- ----- --- --------- --------- ---------\n");
    printf("%33.4lf %9.4lf %9.4lf\n\n", (double)subtotal / 100, (double)taxtotal / 100, (double)TOTAL / 100);

    printf("Daily retail sales represented by coins\n");
    printf("=======================================\n\n");

    int Toonies1, Loonies1, Quarters1, Dimes1, Nickels1, Pennies1;

    Toonies1 = subtotal % 200;                                          //Toonies = 200cents
    Loonies1 = subtotal % 100;                                          //loonies = 100cents
    Quarters1 = subtotal % 25;                                          //Qarters = 25cents
    Dimes1 = subtotal % 10;                                             //Dimes = 10cents
    Nickels1 = subtotal % 5;                                            //Nickels = 5cents
    Pennies1 = subtotal % 1;                                            //Pennies = 1cent

    printf("Sales EXCLUDING tax\n");
    printf("Coin     Qty   Balance\n");
    printf("-------- --- ---------\n");
    printf("%22.4lf\n", (double)subtotal / 100);
    printf("Toonies  %3d %9.4lf\n", (int)subtotal / 200, (double)Toonies1 / 100);
    printf("Loonies  %3d %9.4lf\n", (int)(subtotal % 200) / 100, (double)Loonies1 / 100);
    printf("Quarters %3d %9.4lf\n", (int)(subtotal % 100) / 25, (double)Quarters1 / 100);
    printf("Dimes    %3d %9.4lf\n", (int)(subtotal % 25) / 10, (double)Dimes1 / 100);
    printf("Nickels  %3d %9.4lf\n", (int)(subtotal % 10) / 5, (double)Nickels1 / 100);
    printf("Pennies  %3d %9.4lf\n\n", (int)(subtotal % 5) / 1, (double)Pennies1 / 100);

    average1 = (double)subtotal / (Pshirts + Sshirts + Tshirts);
    printf("Average cost/shirt: $%.4lf\n\n", (average1 / 100) + 0.00005);

    int Toonies2, Loonies2, Quarters2, Dimes2, Nickels2, Pennies2;

    Toonies2 = TOTAL % 200;                                          //Toonies = 200cents
    Loonies2 = TOTAL % 100;                                          //loonies = 100cents
    Quarters2 = TOTAL % 25;                                          //Qarters = 25cents
    Dimes2 = TOTAL % 10;                                             //Dimes = 10cents
    Nickels2 = TOTAL % 5;                                            //Nickels = 5cents
    Pennies2 = TOTAL % 1;                                            //Pennies = 1cent

    printf("Sales INCLUDING tax\n");
    printf("Coin     Qty   Balance\n");
    printf("-------- --- ---------\n");
    printf("%22.4lf\n", (double)TOTAL / 100);
    printf("Toonies  %3d %9.4lf\n", (int)TOTAL / 200, (double)Toonies2 / 100);
    printf("Loonies  %3d %9.4lf\n", (int)(TOTAL % 200) / 100, (double)Loonies2 / 100);
    printf("Quarters %3d %9.4lf\n", (int)(TOTAL % 100) / 25, (double)Quarters2 / 100);
    printf("Dimes    %3d %9.4lf\n", (int)(TOTAL % 25) / 10, (double)Dimes2 / 100);
    printf("Nickels  %3d %9.4lf\n", (int)(TOTAL % 10) / 5, (double)Nickels2 / 100);
    printf("Pennies  %3d %9.4lf\n\n", (int)(TOTAL % 5) / 1, (double)Pennies2 / 100);

    average2 = (double)TOTAL / (Pshirts + Sshirts + Tshirts);
    printf("Average cost/shirt: $%.4lf\n", (average2 / 100) + 0.00005);

    return 0;
}