/*
*****************************************************************************
                          Workshop - #3 (P1)
Full Name  :Harleen Kaur
Student ID#:163071210
Email      :hkaur636@myseneca.ca
Section    :ZGG

Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
*****************************************************************************
*/

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

int main(void)
{

    const double TAX = 0.13;
    const char patSize = 'S';
    double small_size, medium_size, large_size_size;
    int price_small_size, price_medium_size, price_large_size, number_of_shirts, sub, tax, total;

    printf("Set Shirt Prices\n");
    printf("================\n");
    printf("Enter the price for a SMALL shirt: $");
    scanf("%lf", &small_size);
    printf("Enter the price for a MEDIUM shirt: $");
    scanf("%lf", &medium_size);
    printf("Enter the price for a LARGE shirt: $");
    scanf("%lf", &large_size_size);

    printf("\n");

    price_small_size = small_size * 100;
    price_medium_size = medium_size * 100;
    price_large_size = large_size_size * 100;

    printf("Shirt Store Price List\n");
    printf("======================\n");
    printf("SMALL  : $%.2lf\n", (double)price_small_size / 100);
    printf("MEDIUM : $%.2lf\n", (double)price_medium_size / 100);
    printf("LARGE  : $%.2lf\n", (double)price_large_size / 100);

    printf("\n");

    printf("Patty's shirt size is '%c'\n", patSize);
    printf("Number of shirts Patty is buying: ");
    scanf("%d", &number_of_shirts);

    sub = price_small_size * number_of_shirts;
    tax = ((sub * (TAX * 100)) + 50) / 100;
    total = (sub + tax);

    printf("\nPatty's shopping cart...\n");
    printf("Contains : %d shirts\n", number_of_shirts);
    printf("Sub-total: $%8.4lf\n", (double)sub / 100);
    printf("Taxes    : $%8.4lf\n", (double)tax / 100);
    printf("Total    : $%8.4lf\n", (double)total / 100);

    return 0;
}