/*
*****************************************************************************
                          Workshop - #3 (P1)
Full Name  :Harleen Kaur
Student ID#:163071210
Email      :hkaur636@myseneca.ca
Section    :ZGG

Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
*****************************************************************************
*/


#define _CRT_SECURE_NO_WARNINGS
#define MIN_YEAR 2012
#define MAX_YEAR 2022
#define LOG_DAYS 3
#include <stdio.h>

int main(void)
{
    const int JAN = 1, DEC = 12;
    int month, year, day;
    double mor_rate, eve_rate, total_mrating = 0, total_erating = 0, average_mrating, average_erating, overall_total, overall_average;
    printf("General Well-being Log\n======================\n");
    printf("Set the year and month for the well-being log (YYYY MM): ");
    scanf("%d %d", &year, &month);
    while (!(((year >= MIN_YEAR) && (year <= MAX_YEAR)) && ((month >= JAN) && (month <= DEC)))) {
        if ((year < MIN_YEAR) || (year > MAX_YEAR)) {
            printf("   ERROR: The year must be between 2012 and 2022 inclusive\n");
        }
        if (month < JAN || month > DEC) {
            printf("   ERROR: Jan.(1) - Dec.(12)\n");
        }
        printf("Set the year and month for the well-being log (YYYY MM): ");
        scanf("%d %d", &year, &month);

    }
    printf("\n");
    printf("*** Log date set! ***\n");


    for (day = 1; day <= LOG_DAYS; day++) {
        switch (month) {
        case 1:
            printf("\n");
            printf("%d-JAN-0%d\n", year, day);
            break;
        case 2:
            printf("\n");
            printf("%d-FEB-0%d\n", year, day);
            break;
        case 3:
            printf("\n");
            printf("%d-MAR-0%d\n", year, day);
            break;
        case 4:
            printf("\n");
            printf("%d-APR-0%d\n", year, day);
            break;
        case 5:
            printf("\n");
            printf("%d-MAY-0%d\n", year, day);
            break;
        case 6:
            printf("\n");
            printf("%d-JUN-0%d\n", year, day);
            break;
        case 7:
            printf("\n");
            printf("%d-JUL-0%d\n", year, day);
            break;
        case 8:
            printf("\n");
            printf("%d-AUG-0%d\n", year, day);
            break;
        case 9:
            printf("\n");
            printf("%d-SEP-0%d\n", year, day);
            break;
        case 10:
            printf("\n");
            printf("%d-OCT-0%d\n", year, day);
            break;
        case 11:
            printf("\n");
            printf("%d-NOV-0%d\n", year, day);
            break;
        case 12:
            printf("\n");
            printf("%d-DEC-0%d\n", year, day);
            break;
        }
        printf("   Morning rating (0.0-5.0): ");
        scanf("%lf", &mor_rate);
        while (!((mor_rate >= 0.0) && (mor_rate <= 5.0))) {
            if (mor_rate < 0 || mor_rate>5.0) {
                printf("      ERROR: Rating must be between 0.0 and 5.0 inclusive!\n");
            }
            printf("   Morning rating (0.0-5.0): ");
            scanf("%lf", &mor_rate);
        }
        total_mrating += mor_rate;
        printf("   Evening rating (0.0-5.0): ");
        scanf("%lf", &eve_rate);
        while (!((eve_rate >= 0.0) && (eve_rate <= 5.0))) {
            if (eve_rate < 0 || eve_rate>5.0) {
                printf("      ERROR: Rating must be between 0.0 and 5.0 inclusive!\n");
            }
            printf("   Evening rating (0.0-5.0): ");
            scanf("%lf", &eve_rate);
        }
        total_erating += eve_rate;

    }
    average_mrating = total_mrating / (double)LOG_DAYS;
    average_erating = total_erating / (double)LOG_DAYS;
    overall_total = total_mrating + total_erating;
    overall_average = (average_mrating + average_erating) / 2;
    printf("\n");
    printf("Summary\n=======\n");
    printf("Morning total rating: %.3lf\n", total_mrating);
    printf("Evening total rating:  %.3lf\n", total_erating);
    printf("----------------------------\n");
    printf("Overall total rating: %.3lf\n", overall_total);
    printf("\n");
    printf("Average morning rating:  %.1lf\n", average_mrating);
    printf("Average evening rating:  %.1lf\n", average_erating);
    printf("----------------------------\n");
    printf("Average overall rating:  %.1lf\n", overall_average);
    return 0;
}