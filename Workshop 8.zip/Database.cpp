#include "Database.h"

namespace sdds {

    template<>
    void Database<std::string>::encryptDecrypt(std::string& value) {
        const char secret[]{ "secret encryption key" };
        for (char& c : value) {
            for (const char& k : secret) {
                c = c ^ k;
            }
        }
    }
    template<>
    void Database<long long>::encryptDecrypt(long long& value) {
        const char secret[]{ "super secret encryption key" };
        char* bytes = reinterpret_cast<char*>(&value);
        size_t numBytes = sizeof(value);
        for (size_t i = 0; i < numBytes; i++) {
            for (const char& k : secret) {
                bytes[i] = bytes[i] ^ k;
            }
        }
    }
}