#pragma once
#ifndef TIMEDTASK_H
#define TIMEDTASK_H

#include <string>
#include <iostream>
#include <chrono>
#define NUM_OF_TASKS 10


namespace sdds
{

    struct Task 
    {
        std::string name;
        std::string time_unit;
        std::chrono::steady_clock::duration duration;
    };


    class TimedTask
    {
        int record_count;
        std::chrono::steady_clock::time_point start_time, end_time;
        Task tasks[NUM_OF_TASKS];

    public:
        TimedTask();

        //copy constructor
        TimedTask(const TimedTask& other);
        //copy assignment operator
        TimedTask& operator=(const TimedTask& other);

        //modifier
        void startClock();
        void stopClock();
        void addTask(const char* name);

        friend std::ostream& operator<<(std::ostream& os, const TimedTask& task);
    };

}

#endif