#pragma once
#ifndef PROTEINDATABASE_H
#define PROTEINDATABASE_H

#include <iostream>
#include <string>

namespace sdds
{

    class ProteinDatabase
    {

        size_t protein_count;
        std::string* proteins;

    public:
        ProteinDatabase();
        ProteinDatabase(const char* filename);
        ~ProteinDatabase();

        //copy constructor
        ProteinDatabase(const ProteinDatabase& other);
        //copy assignment operator
        ProteinDatabase& operator=(const ProteinDatabase& other);

        //move constructor
        ProteinDatabase(ProteinDatabase&& other);
        //move assignment operator
        ProteinDatabase& operator=(ProteinDatabase&& other);


        size_t size() const;
        const std::string operator[](size_t index) const;

    };
}

#endif