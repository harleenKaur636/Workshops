#include "TimedTask.h"
#include <iostream>
#include <iomanip>

namespace sdds
{

    TimedTask::TimedTask()
    {
        record_count = 0;
    }

    // copy constructor
    TimedTask::TimedTask(const TimedTask& other)
    {
        *this = other;
    }

    // copy assignment operator
    TimedTask& TimedTask::operator=(const TimedTask& other)
    {
        if (this != &other)
        {
            record_count = other.record_count;
            start_time = other.start_time;
            end_time = other.end_time;
            for (int i = 0; i < record_count; i++)
            {
                tasks[i] = other.tasks[i];
            }
        }
        return *this;
    }

    void TimedTask::startClock()
    {
        start_time = std::chrono::steady_clock::now();
    }

    void TimedTask::stopClock()
    {
        end_time = std::chrono::steady_clock::now();
    }

    void TimedTask::addTask(const char* name)
    {
        if (record_count < NUM_OF_TASKS)
        {
            tasks[record_count].name = name;
            tasks[record_count].time_unit = "nanoseconds";
            tasks[record_count].duration = std::chrono::steady_clock::now() - start_time;
            record_count++;
        }
    }

    std::ostream& operator<<(std::ostream& os, const TimedTask& task)
    {
        os << "--------------------------" << std::endl;
        os << "Execution Times:" << std::endl;
        os << "--------------------------" << std::endl;
        for (int i = 0; i < task.record_count; i++)
        {
            os << std::setw(21) << std::left << task.tasks[i].name
                << std::setw(13) << std::right << std::chrono::duration_cast<std::chrono::milliseconds>(task.tasks[i].duration).count() << " " << task.tasks[i].time_unit << std::endl;
        }
        os << "--------------------------" << std::endl;
        return os;
    }

}