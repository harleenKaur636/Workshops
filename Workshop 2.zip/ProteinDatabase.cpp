#include "ProteinDatabase.h"
#include <fstream>

namespace sdds
{

    ProteinDatabase::ProteinDatabase()
    {
        protein_count = 0;
        proteins = nullptr;
    }

    ProteinDatabase::ProteinDatabase(const char* filename)
    {

        std::ifstream file(filename);
        std::string line;
        char ch;

        int cnt = 0;
        while (file.get(ch))
        {
            if (ch == '>')
                cnt++;
        }

        protein_count = cnt;

        // std::cout << protein_count << std::endl;

        proteins = new std::string[protein_count];

        file.clear();
        file.seekg(0);

        std::getline(file, line);
        for (size_t i = 0; i < protein_count; i++)
        {
            while (std::getline(file, line) && line[0] != '>')
                proteins[i] += line;
        }

        file.close();
    }



    //copy constructor
    ProteinDatabase::ProteinDatabase(const ProteinDatabase& other)
    {
        proteins = nullptr;
        *this = other;
    }

    //copy assignment operator
    ProteinDatabase& ProteinDatabase::operator=(const ProteinDatabase& other)
    {
        if (this != &other)
        {
            delete[] proteins;
            protein_count = other.protein_count;
            proteins = new std::string[protein_count];
            for (size_t i = 0; i < protein_count; i++)
                proteins[i] = other.proteins[i];
        }
        return *this;
    }

    //move constructor
    ProteinDatabase::ProteinDatabase(ProteinDatabase&& other)
    {
        proteins = nullptr;
        *this = std::move(other);
    }

    //move assignment operator
    ProteinDatabase& ProteinDatabase::operator=(ProteinDatabase&& other)
    {
        if (this != &other)
        {
            delete[] proteins;
            protein_count = other.protein_count;
            proteins = other.proteins;
            other.proteins = nullptr;
            other.protein_count = 0;
        }
        return *this;
    }

    ProteinDatabase::~ProteinDatabase()
    {
        delete[] proteins;
        proteins = nullptr;
    }

    size_t ProteinDatabase::size() const
    {
        return protein_count;
    }

    const std::string ProteinDatabase::operator[](size_t index) const
    {
        if (index < protein_count)
            return proteins[index];

        return "";
    }



}