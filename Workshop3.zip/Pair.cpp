#include <iostream>
#include <iomanip>
#include "Pair.h"

sdds::Pair::Pair() : m_key{ "" }, m_value{ "" }  {

}

std::ostream& sdds::operator<<(std::ostream& outputstream, const sdds::Pair& other) {
    outputstream << std::setw(20) << std::right << other.m_key << ": ";
    outputstream << other.m_value;
    return outputstream;
}

bool sdds::Pair::operator==(const sdds::Pair& pair) {
    return m_key == pair.m_key;
}