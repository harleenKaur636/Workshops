#ifndef SDDS_SET_H
#define SDDS_SET_H

#include <cmath>
#include "Collection.h"

namespace sdds {
    template<typename T>
    class Set : public Collection<T, 100> {
    public:
        bool add(const T& newItem) override;
    };
};

template<typename T>
bool sdds::Set<T>::add(const T& newItem) {
    if (Collection<T, 100>::currentsize == 100) {
        return false;
    }
    else {
        for (unsigned int i = 0; i < Collection<T, 100>::currentsize; i++) {
            if (Collection<T, 100>::collection[i] == newItem) {
                return false;
            }
        }

        Collection<T, 100>::collection[Collection<T, 100>::currentsize++] = newItem;
        return true;
    }

}

template<>
bool sdds::Set<double>::add(const double& newItem) {
    if (Collection<double, 100>::currentsize == 100) {
        return false;
    }
    else {
        for (unsigned int i = 0; i < Collection<double, 100>::currentsize; i++) {
            if (std::fabs(Collection<double, 100>::collection[i] - newItem) <= 0.01) {
                return false;
            }
        }

        Collection<double, 100>::collection[Collection<double, 100>::currentsize] = newItem;
        Collection<double, 100>::currentsize++;
        return true;
    }
}

#endif