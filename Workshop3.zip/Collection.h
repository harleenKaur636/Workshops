#ifndef SDDS_COLLECTION_H
#define SDDS_COLLECTION_H

#include <iostream>
#include "Pair.h"

namespace sdds {
    template<typename T, unsigned int CAPACITY>
    class Collection {
    protected:
        unsigned int currentsize = 0;
        T collection[CAPACITY];
        static T defaultObject;

    public:
        unsigned int size() const;
        void display(std::ostream& outputstream = std::cout) const;
        virtual bool add(const T& newItem);
        T operator[](unsigned int position) const;
        virtual ~Collection();
    };
};

template<typename T, unsigned int CAPACITY>
T sdds::Collection<T, CAPACITY>::defaultObject = T{};

template<>
sdds::Pair sdds::Collection<sdds::Pair, 100>::defaultObject = sdds::Pair{ "No Key", "No Value" };

template<typename T, unsigned int CAPACITY>
unsigned int sdds::Collection<T, CAPACITY>::size() const {
    return currentsize;
}

template<typename T, unsigned int CAPACITY>
void sdds::Collection<T, CAPACITY>::display(std::ostream& outputstream) const {
    outputstream << "----------------------\n| Collection Content |\n----------------------" << std::endl;
    for (unsigned int i = 0; i < currentsize; i++) {
        outputstream << collection[i] << std::endl;
    }
    outputstream << "----------------------" << std::endl;
}

template<typename T, unsigned int CAPACITY>
bool sdds::Collection<T, CAPACITY>::add(const T& newItem) {
    if (currentsize == CAPACITY) {
        return false;
    }
    else {
        collection[currentsize] = newItem;
        currentsize++;
        return true;
    }
};

template<typename T, unsigned int CAPACITY>
T sdds::Collection<T, CAPACITY>::operator[](unsigned int position) const {
    if (position < currentsize) {
        return collection[position];
    }
    else {
        return defaultObject;
    }
};

template<typename T, unsigned int CAPACITY>
sdds::Collection<T, CAPACITY>::~Collection() {};

#endif