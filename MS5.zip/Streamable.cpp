#include<iostream>
#include "Streamable.h"
using namespace std;
namespace sdds 
{
	/*	istream& operator >> (istream& in, Streamable str) 
	{
			return str.read(in);
		}
		ostream& operator<<(ostream& os, Streamable str)
		{
			return str.write(os);
		}*/
}