#define _CRT_SECURE_NO_WARNINGS
#include "foodorder.h"
#include <string>
#include <iostream>
#include <cstring>
#include <iomanip>

using namespace std;
double g_taxrate{ 0 };
double g_dailydiscount{ 0 };

namespace sdds
{
    FoodOrder::FoodOrder()
    {
        setEmpty();
    }

    FoodOrder::~FoodOrder()
    {
        deallocate();
    }

    FoodOrder::FoodOrder(const FoodOrder& foodOrder) 
    {
        *this = foodOrder;
    }

    FoodOrder& FoodOrder::operator=(const FoodOrder& foodOrder)
    {
        if (this != &foodOrder) 
        {
            foodPrice = foodOrder.foodPrice;
            dailySpecial = foodOrder.dailySpecial;

            if (foodOrder.customerName != nullptr) 
            {
                customerName = new char[strlen(foodOrder.customerName) + 1];
                strcpy(customerName, foodOrder.customerName);
            }
            else
            {
                customerName = nullptr;
            }

            if (foodOrder.foodDescription != nullptr) 
            {
                foodDescription = new char[strlen(foodOrder.foodDescription) + 1];
                strcpy(foodDescription, foodOrder.foodDescription);
            }
            else 
            {
                foodDescription = nullptr;
            }

        }
        return *this;
    }


    std::istream& FoodOrder::read(std::istream& is)
    {
        if (is)
        {


            deallocate();


            char temp[256];
            is.getline(temp, 256, ',');


            if (strlen(temp) > 0) 
            {
                customerName = new char[strlen(temp) + 1];
                strcpy(customerName, temp);

                // Reading the Food Description
                char temp2[256];
                is.getline(temp2, 256, ',');
                foodDescription = new char[strlen(temp2) + 1];
                strcpy(foodDescription, temp2);

                // Reading the food price
                is >> foodPrice;
                is.ignore(1);

                // Reading whether there is any special pricing
                char temp3[256];
                is.getline(temp3, 256, '\n');
                if (temp3[0] == 'N') 
                {
                    dailySpecial = false;
                }
                else if (temp3[0] == 'Y') 
                {
                    dailySpecial = true;
                }
            }
            else 
            {
                setEmpty();
            }

        }
        return is;
    }


    void FoodOrder::display() const 
    {

        static int counter{ 1 };

        if (customerName != nullptr)
        {
            cout
                << setw(2) << left << counter << ". "
                << setw(10) << customerName
                << "|" << setw(25) << foodDescription
                << "|" << setw(12) << fixed << setprecision(2) << (foodPrice + (foodPrice * g_taxrate))
                << "|" << setw(13) << right;


            if (dailySpecial) 
            {
                cout << (foodPrice + (foodPrice * g_taxrate)) - g_dailydiscount << endl;
            }
            else 
            {
                cout << endl;
            }

        }
        else 
        {
            cout << setw(2) << left << counter << ". " << "No Order" << endl;
        }
        counter++;
    }


    void FoodOrder::setEmpty()
    {
        customerName = nullptr;
        foodDescription = nullptr;
        foodPrice = 0;
        dailySpecial = false;
    }


    void FoodOrder::deallocate()
    {
        delete[] customerName;
        delete[] foodDescription;
    }
}
