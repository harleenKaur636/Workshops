#pragma once
#ifndef SDDS_FOODORDER_H
#define SDDS_FOODORDER_H
#include <iostream>

extern double g_taxrate;
extern double g_dailydiscount;

namespace sdds
{
    class FoodOrder
    {
    private:
        char* customerName;
        char* foodDescription;
        double foodPrice;
        bool dailySpecial;
        void setEmpty();
        void deallocate();

    public:
        FoodOrder();
        ~FoodOrder();
        FoodOrder(const FoodOrder& foodOrder);
        FoodOrder& operator=(const FoodOrder& foodOrder);
        std::istream& read(std::istream& is);
        void display() const;
    };
}

#endif