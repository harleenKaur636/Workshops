#include "process_data.h"

namespace sdds_ws9 {

	void computeAvgFactor(const int* arr, int size, int divisor, double& avg) {
		avg = 0;
		for (int i = 0; i < size; i++) {
			std::this_thread::sleep_for(std::chrono::nanoseconds(50));
			avg += arr[i];
		}
		avg /= divisor;
	}

	void computeVarFactor(const int* arr, int size, int divisor, double avg, double& var) {
		var = 0;
		for (int i = 0; i < size; i++) {
			std::this_thread::sleep_for(std::chrono::nanoseconds(50));
			var += (arr[i] - avg) * (arr[i] - avg);
		}
		var /= divisor;
	}
	ProcessData::operator bool() const {
		return total_items > 0 && data && num_threads > 0 && averages && variances && p_indices;
	}

	ProcessData::ProcessData(std::string filename, int n_threads) {
		// TODO: Open the file whose name was received as parameter and read the content
		//         into variables "total_items" and "data". Don't forget to allocate
		//         memory for "data".
		//       The file is binary and has the format described in the specs.

		// ==

		// Open file in binary mode
		std::ifstream f(filename, std::fstream::binary);

		// Read total items
		f.read((char*)&total_items, sizeof(total_items));

		// Allocate buffer for the data
		data = new int[total_items];

		// Read data into allocated buffer
		f.read((char*)data, sizeof(int) * total_items);

		// File is automatically closed by ifstream destructor

		// ==

		std::cout << "Item's count in file '" << filename << "': " << total_items << std::endl;
		std::cout << "  [" << data[0] << ", " << data[1] << ", " << data[2] << ", ... , "
			<< data[total_items - 3] << ", " << data[total_items - 2] << ", "
			<< data[total_items - 1] << "]\n";

		// Following statements initialize the variables added for multi-threaded 
		//   computation
		num_threads = n_threads;
		averages = new double[num_threads] {};
		variances = new double[num_threads] {};
		p_indices = new int[num_threads + 1]{};
		for (int i = 0; i < num_threads + 1; i++)
			p_indices[i] = i * (total_items / num_threads);
	}

	ProcessData::~ProcessData() {
		delete[] data;
		delete[] averages;
		delete[] variances;
		delete[] p_indices;
	}

	// TODO Improve operator() function from part-1 for multi-threaded operation. Enhance the  
	//   function logic for the computation of average and variance by running the 
	//   function computeAvgFactor and computeVarFactor in multile threads. 
	// The function divides the data into a number of parts, where the number of parts is 
	//   equal to the number of threads. Use multi-threading to compute average-factor for 
	//   each part of the data by calling the function computeAvgFactor. Add the obtained 
	//   average-factors to compute total average. Use the resulting total average as the 
	//   average value argument for the function computeVarFactor, to compute variance-factors 
	//   for each part of the data. Use multi-threading to compute variance-factor for each 
	//   part of the data. Add computed variance-factors to obtain total variance.
	// Save the data into a file with filename held by the argument fname_target. 
	// Also, read the workshop instruction.

	int ProcessData::operator()(std::string outFilePath, double& outAvg, double& outVari) {

		// First of all, start a thread to write out file to disk
		std::thread writeFileToDiskThread([&]() {
			// Open file in binary mode
			std::ofstream f(outFilePath);

			// Write total items
			f.write((char*)&total_items, sizeof(total_items));

			// Write data from allocated buffer to file
			f.write((char*)data, sizeof(int) * total_items);

			// File is automatically closed by ofstream destructor
			});

		// Now, to calculate variance and average

		// Number of items in each chunk
		const auto thread_chunk_size = total_items / num_threads;

		// Do multi-threaded avg and var calculations
		{
			std::vector<std::thread> threads;
			threads.reserve(num_threads); // Pre-allocate memory for threads

			// Helper function to join all threads (wait for them to finish)
			const auto JoinThreads = [&] {
				for (int i = 0; i < num_threads; i++) {
					threads[i].join();
				}
				threads.clear();
			};

			// Calculate average first, as it's necessary to calculate variance
			{
				const auto boundComputeAvgFactor = std::bind(computeAvgFactor, std::placeholders::_1, std::placeholders::_2, total_items, std::placeholders::_3);
				for (int i = 0; i < num_threads; i++) {
					// Clean, proper way to make this work - But since it is required to use `std::bind` I'll use it.
					//threads.emplace_back([&, i](){
					//	computeAvgFactor(&data[p_indices[i]], thread_chunk_size, total_items, averages[i]);
					//});

					// Had to use `std::ref` here, because otherwise the value is coped, and when the function is invoked it references the copied element
					// not the one in the `averages` array.
					threads.emplace_back(boundComputeAvgFactor, &data[p_indices[i]], thread_chunk_size, std::ref(averages[i]));
				}

				JoinThreads();
			}

			// Calculate total average
			{
				outAvg = 0.0;
				for (int i = 0; i < num_threads; i++) {
					outAvg += averages[i];
				}
			}

			// Calculate total variance
			{
				// Run worker function on each thread
				const auto boundComputeVarFactor = std::bind(computeVarFactor, std::placeholders::_1, std::placeholders::_2, total_items, outAvg, std::placeholders::_3);
				for (int i = 0; i < num_threads; i++) {
					// Clean, proper way to make this work - But since it is required to use `std::bind` I'll use it.
					//threads.emplace_back([&, i](){
					//	computeVarFactor(&data[p_indices[i]], thread_chunk_size, total_items, outAvg, variances[i]);
					//});
					threads.emplace_back(boundComputeVarFactor, &data[p_indices[i]], thread_chunk_size, std::ref(variances[i]));
				}

				JoinThreads();
			}

			// Calculate total variance
			{
				outVari = 0.0;
				for (int i = 0; i < num_threads; i++) {
					outVari += variances[i];
				}
			}
		}

		// Await this thread to finish as well
		writeFileToDiskThread.join();

		return 1;
	}
}
