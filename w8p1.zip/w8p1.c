/*
*****************************************************************************
                          Workshop - #8 (P1)
Full Name  : Harleen Kaur
Student ID#: 163071210
Email      : hkaur636@myseneca.ca
Section    : ZGG

Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
*****************************************************************************
*/

#define _CRT_SECURE_NO_WARNINGS


// System Libraries
#include <stdio.h>

// User Libraries
#include "w8p1.h"

// 1. Get user input of int type and validate for a positive non-zero number
//    (return the number while also assigning it to the pointer argument)
int getIntPositive(int* num) {
    int n;
    do {
        scanf("%d", &n);
        if (n <= 0) {
            printf("ERROR: Enter a positive value: ");
        }
    } while (n <= 0);

    if (num != NULL)
        *num = n;

    return n;
}

// 2. Get user input of double type and validate for a positive non-zero number
//    (return the number while also assigning it to the pointer argument)
double getDoublePositive(double* dnum) {
    double x;
    do {
        scanf("%lf", &x);
        if (x <= 0) {
            printf("ERROR: Enter a positive value: ");
        }
        else {
            if (dnum != NULL)
                *dnum = x;
        }
    } while (x <= 0);
    return x;
}

// 3. Opening Message (include the number of products that need entering)
void openingMessage(const int number) {
    printf("Cat Food Cost Analysis\n");
    printf("======================\n");
    printf("\n");
    printf("Enter the details for %d dry food bags of product data for analysis.\n", number);
    printf("NOTE: A 'serving' is %dg\n\n", MAX_GRAMS);
    return;
}

// 4. Get user input for the details of cat food product
struct CatFoodInfo getCatFoodInfo(const int n) {
    struct CatFoodInfo catfood;
    printf("Cat Food Product #%d\n", n + 1);
    printf("--------------------\n");
    printf("SKU           : ");
    getIntPositive(&catfood.sku_num);
    printf("PRICE         : $");
    getDoublePositive(&catfood.product_price);
    printf("WEIGHT (LBS)  : ");
    getDoublePositive(&catfood.product_weight);
    printf("CALORIES/SERV.: ");
    getIntPositive(&catfood.calories);
    printf("\n");
    return catfood;
}

// 5. Display the formatted table header
void displayCatFoodHeader(void)
{
    printf("SKU         $Price    Bag-lbs Cal/Serv\n");
    printf("------- ---------- ---------- --------\n");
}

// 6. Display a formatted record of cat food data
void displayCatFoodData(int sku, double* price, int calories, double* weight) {
    printf("%07d %10.2lf %10.1lf %8d\n", sku, *price, *weight, calories);
    return;
}

// 7. Logic entry point
void start() {
    struct CatFoodInfo catfood[MAX_PRODUCTS] = { {0} };
    int num_products = 3, i;
    openingMessage(num_products);
    for (i = 0; i < num_products; i++) {
        catfood[i] = getCatFoodInfo(i);
    }
    displayCatFoodHeader();
    for (i = 0; i < num_products; i++) {
        displayCatFoodData(catfood[i].sku_num, &catfood[i].product_price, catfood[i].calories, &catfood[i].product_weight);
    }
    printf("\n\n");
    return;
}