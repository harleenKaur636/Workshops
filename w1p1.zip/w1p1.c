#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main(void)
{
	printf("Workshop 1 Part-1\n");
	printf("=================\n\n");
	printf("I'm displaying this using the 'printf' stdio\n");
	printf("(standard input output) library function!\n\n");
	printf("Dear teacher,\n\n");
	printf("  I promise I will work hard from this day onward.\n");
	printf("  I acknowledge that practice is extremely important,\n");
	printf("  so I will do all workshops, quizzes, and assignments.\n");
	printf("Sincerely,\n\n");
	printf("ArjunSagar Dhunna\n");
	printf("Student ID# 157099219");
	return 0;
}